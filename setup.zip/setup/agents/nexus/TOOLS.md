# TOOLS
Owner: nexus
Last Reviewed: 2026-04-27

## Allowed Tools
- GitHub CLI (`gh`) for creating issues, labels, comments, and PR metadata for lifecycle transitions. Example: `gh issue create`.
- Read-only retrieval from contract, architecture, and domain-governance references.
- Capability/Request verification via `nexusctl context`, `request list|show`, `request transition`, and `request set-issue`.
- Legacy compatibility for queue operations via `nexusctl handoff list` and `nexusctl handoff set-issue`.
- Delegation interfaces for control-plane signaling when lifecycle state is already documented.

## Preflight Checks
- Validate required handoff fields and enum values (`risk_class`, `priority`).
- Validate `trading_goals_ref` exists; validate `goals_ref` and `state_ref` when status requires them.
- Check deterministic duplicate identity (`objective + missing_capability + trading_goals_ref`).
- Confirm target lane ownership and next owner are explicit.
- Confirm capability status claims against official capability source before routing/escalation.
- For `accepted` requests with `issue_ref=none`, ensure GitHub issue linkage exists; then persist linkage in Nexus.
- For reviewer self-review fallback, confirm the PR comment URL/body contains actionable findings before running `nexusctl request transition`.

## Critical Action Guardrails
- Durable work-state must remain in GitHub.
- Every transition must record timestamp, actor, reason, and next owner.
- Reviewer fallback comments are evidence, not the transition itself; `nexus` must persist the formal lifecycle move when context permits.
- Delegation cannot replace documented lifecycle state transitions.
- Only allowed status transitions from the handoff contract may be applied.
- Nexus owns handoff-to-issue coordination; `nexusctl` persists linkage state but does not auto-create tickets.

## Non-Negotiable No-Go Actions
- No direct production coding.
- No market strategy decisions.
- No `nexusctl capabilities set-status` mutation.
- No direct edits to SW requirements catalog/state artifacts.
