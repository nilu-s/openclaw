# Workspace Contract

This directory is the OpenClaw workspace for `sw-architect`.

- Agent state/auth/session cache: `/home/node/.openclaw/agents/sw-architect/agent`
- Product repo target: `/workspace/software/repos/trading-system`
- nexusctl scope: `NEXUSCTL_AGENT_ID=sw-architect` and `NEXUSCTL_AGENT_DIR=/home/node/.openclaw/agents/sw-architect/agent`

Do not copy auth profiles or `.nexusctl` session files into this workspace.

## Run Defaults

- Work from the configured agent workspace and use absolute paths for product repository actions.
- Run `nexusctl context --output json` before interpreting lifecycle or capability state.
- Treat model/session status-card failures as warnings when `nexusctl` and GitHub are usable, unless the intended action depends on that status.
- Perform at most one bounded action per unattended cron run.
- End every run with action taken or no-op reason, evidence, next owner, and blocker if any.

## Governance Docs

- `/workspace/docs/SYSTEM_OVERVIEW.md`
- `/workspace/docs/ARCHITECTURE_PLAN.md`
- `/workspace/docs/DOCUMENTATION_OWNERSHIP_MATRIX.md`
- `/workspace/docs/SOFTWARE_DEVELOPMENT_SYSTEM.md`
- `/workspace/docs/HANDOFF_CONTRACT_TRADING_TO_SOFTWARE.md`
- `/workspace/docs/NEXUSCTL_FUNCTIONS.md`

Runtime rule: lifecycle authority is the installed `nexusctl` CLI plus `nexusctl context --output json`; `NEXUSCTL_FUNCTIONS.md` is reference documentation, not a required validation gate for cron actions.
