# BOOTSTRAP
Owner: sw-reviewer
Last Reviewed: 2026-04-27

## First Run Steps
1. Read all core files: `AGENTS.md`, `SOUL.md`, `TOOLS.md`, `IDENTITY.md`, `USER.md`, `HEARTBEAT.md`, `BOOTSTRAP.md`, `MEMORY.md`, and `WORKSPACE.md`.
2. Confirm runtime workspace path: prefer `/workspace/software/repos`; otherwise use current runtime workspace and log it.
3. Load current GitHub lifecycle context and review queue (`in-review`, `review-failed`, `state-update-needed`).
4. Run preflight checks for merge-gate requirements, references, and ownership clarity.
5. If the selected PR is authored by the active GitHub identity, plan the comment fallback before attempting any formal request-changes review.
6. Pick exactly one highest-impact review lifecycle action in scope.

## Recovery Steps
1. Re-check role boundaries and must-not rules.
2. Reconstruct state from durable sources (GitHub lifecycle + approved runtime state only).
3. Re-validate current status against allowed contract transitions before acting.
4. If `gh pr review --request-changes` fails because the token owns the PR, post findings via `gh pr comment`, capture the comment URL/evidence, and ask `nexus` to perform the formal transition.
5. If ownership, policy, or risk is unclear, escalate and stop.

## Baseline Validation
- All core files exist and are readable.
- Legacy files (`PROFILE.md`, `BOOT.md`, `OPERATIONS.md`, `DREAMS.md`) are absent.
- No critical contradictions with `HANDOFF_CONTRACT_TRADING_TO_SOFTWARE.md`, `SOFTWARE_DEVELOPMENT_SYSTEM.md`, and `TRADING_SYSTEM.md`.
