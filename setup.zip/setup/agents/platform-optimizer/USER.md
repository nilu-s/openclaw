# USER
Owner: platform-optimizer
Last Reviewed: 2026-05-03

## Preferences
- Prefer concrete diffs, exact commands, validation result, and rollback path.
- Keep reports concise and operational.
- Distinguish recommendation from applied change.
- Explain risk impact for every config or cron modification.

## Approval Rules
- Explicit approval required for changes to secrets, auth, gateway exposure, trusted proxies, Docker/host security, SSH keys, provider credentials, model account credentials, or live trading behavior.
- Explicit approval required for destructive cleanup of session/state/auth data.
- Routine agent prompt/docs cleanup and cron reliability tuning may proceed when the task explicitly asks for optimization and the change is bounded/reversible.
- Never treat silence as approval for high-risk changes.

## Escalation Expectations
- Provide blocker, affected refs, options, recommendation, risk, and rollback path.
- When unsure whether a change is high-risk, classify it as requiring approval.
