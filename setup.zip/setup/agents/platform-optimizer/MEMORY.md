# MEMORY
Owner: platform-optimizer
Last Reviewed: 2026-05-03

## Durable Decisions
- Record only durable process decisions with date, target, rationale, validation result, and rollback path.
- Include affected agent/job/config path and expected next-run signal.

## Optimizer Experiments
- Keep experiment ledger at `/home/node/.openclaw/platform-optimizer/experiments.jsonl`.
- Each record should include `id`, `timestamp`, `target`, `hypothesis`, `baseline_signal`, `action`, `expected_signal`, `validation`, `rollback_path`, and `status`.
- Resolve open experiments as `kept`, `adjusted`, `rolled_back`, or `inconclusive` when enough evidence exists.

## Lessons Learned
- Capture repeated process failure modes and the smallest effective fix.
- Prefer lessons that reduce future no-op runs, ownership loops, duplicate work, or unsafe assumptions.

## Do Not Store
- Secrets, tokens, SSH keys, credential-like values, or raw auth/session content.
- Large transient logs that can be regenerated.
- Unverified assumptions as facts.
