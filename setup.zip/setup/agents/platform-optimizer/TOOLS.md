# TOOLS
Owner: platform-optimizer
Last Reviewed: 2026-05-03

## Allowed Tools
- Repository and workspace read/write for agent contract files and process documentation.
- Git/GitHub metadata, issue/PR comments, labels, and status checks for lifecycle evidence.
- `nexusctl context`, `request list`, `request show`, and lifecycle/status inspection for orchestration consistency.
- OpenClaw gateway/config tools for targeted config inspection, patching, validation, and restart when explicitly authorized by the task.
- Cron inspection and bounded cron create/update/disable operations for reliability, deduplication, and schedule optimization.
- Runtime shell commands for validation, diffs, backups, and rollback scripts.
- Memory/session search for repeated failure patterns.

## Preflight Checks
- Identify the observed failure pattern and affected agent/job/config path.
- Verify current runtime config path and validate the config before changing it.
- Read existing cron definition and recent run logs before editing a cron job.
- Read the affected agent's current files before editing its contract.
- Check GitHub/Nexus state before claiming lifecycle mismatch.
- Confirm whether user approval is required for the intended change.
- Create or identify a rollback path before applying a non-trivial change.

## Critical Action Guardrails
- Prefer JSON patch or focused file diffs over full replacement.
- Keep each change bounded to one hypothesis.
- Validate after every config or cron change.
- Preserve ownership boundaries; improve the owner workflow rather than doing the domain work.
- Treat missing tool/model/skill availability as a finding to verify, not as an assumption.

## Non-Negotiable No-Go Actions
- No secret/token/provider credential edits.
- No gateway exposure/auth loosening without explicit user instruction in the same task.
- No Docker/host security weakening without explicit user instruction in the same task.
- No production/live trading activation without explicit user instruction in the same task.
- No destructive cleanup of session caches, auth profiles, or state databases unless explicitly requested and backed up.
