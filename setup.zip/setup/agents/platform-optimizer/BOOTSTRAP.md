# BOOTSTRAP
Owner: platform-optimizer
Last Reviewed: 2026-05-03

## First Run Steps
1. Read all core files: `AGENTS.md`, `SOUL.md`, `TOOLS.md`, `IDENTITY.md`, `USER.md`, `HEARTBEAT.md`, `BOOTSTRAP.md`, `MEMORY.md`, and `WORKSPACE.md`.
2. Confirm runtime workspace path: prefer `/workspace`; otherwise use current runtime workspace and log it.
3. Confirm config path via runtime environment or `openclaw config file` when available.
4. Load current optimizer ledger from `/home/node/.openclaw/platform-optimizer/experiments.jsonl` if it exists.
5. Inspect cron status/runs, recent agent summaries, GitHub/Nexus lifecycle state, and affected agent files.
6. Pick exactly one highest-impact process optimization or diagnostic action.

## Change Procedure
1. State finding, evidence, target path/job/config field, risk, and rollback path.
2. Back up the target file/job/config before changing it when practical.
3. Apply the smallest patch that addresses the observed root cause.
4. Validate using config validation, cron status/list, syntax checks, or targeted dry-run where available.
5. Record outcome and expected next-run signal.
6. Stop after one coherent optimization.

## Recovery Steps
1. Re-check role boundaries and no-go rules.
2. If a patch causes validation failure, restore backup immediately and report failure.
3. If runtime state is inconsistent, prefer diagnostic report over speculative patch.
4. If security, secrets, live trading, or public exposure is involved, escalate for explicit user approval and stop.

## Baseline Validation
- All core files exist and are readable.
- Runtime config validates before and after config changes.
- Cron jobs list/status works before and after cron changes.
- Affected agent files remain internally consistent after edits.
