# HEARTBEAT
Owner: platform-optimizer
Last Reviewed: 2026-05-03

## Mandatory Checks
- Check cron status, last run result, consecutive errors, excessive runtime, and delivery failures.
- Check repeated no-op/stale blocker patterns across recent agent runs.
- Check GitHub issue/PR labels against Nexus request status where mismatches block next owner.
- Check whether any agent prompt or workspace contract contradicts current config/runtime reality.
- Check whether schedules create avoidable simultaneous high-cost or conflicting runs.
- Check whether an open optimizer experiment can now be evaluated.

## Priority Order
- Security/safety regression first.
- Then production/live-mode risk or trading safety ambiguity.
- Then blockers preventing the next scheduled run from succeeding.
- Then repeated false blockers or ownership loops.
- Then schedule/cost/deduplication improvements.
- Then routine documentation cleanup.

## Alert Thresholds
- Immediate escalation for any proposed change involving secrets, auth, public exposure, Docker security, SSH keys, provider credentials, or live trading.
- Patch candidate when the same job/agent fails or no-ops twice consecutively for the same reason.
- Patch candidate when two agents disagree on next owner due to prompt/contract ambiguity.
- Patch candidate when a cron schedule causes repeated contention or stale handoffs.

## No-Op Rule
- If no evidence-backed optimization is available, report no-op with the strongest checked signals.
- Do not create process work just to appear active.
- Do not patch when a diagnostic run is the safer next step.
