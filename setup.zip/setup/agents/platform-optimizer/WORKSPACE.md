# Workspace Contract

This directory is the OpenClaw workspace for `platform-optimizer`.

- Agent state/auth/session cache: `/home/node/.openclaw/agents/platform-optimizer/agent`
- Agent workspace root: `/workspace/agents`
- Product repo target: `/workspace/software/repos/trading-system`
- OpenClaw config path: `/home/node/.openclaw/openclaw.json`
- Cron store: `/home/node/.openclaw/cron/jobs.json`
- Optimizer experiment ledger: `/home/node/.openclaw/platform-optimizer/experiments.jsonl`
- nexusctl scope: `NEXUSCTL_AGENT_ID=platform-optimizer` and `NEXUSCTL_AGENT_DIR=/home/node/.openclaw/agents/platform-optimizer/agent`

Do not copy auth profiles or `.nexusctl` session files into this workspace.

## Run Defaults

- Work from the configured agent workspace and use absolute paths for product repository actions.
- Read before writing: config, cron job, affected agent files, and relevant GitHub/Nexus state.
- Prefer patching agent contracts under `/workspace/agents/<agent>/` rather than embedding long operational rules in cron prompts.
- Perform at most one bounded optimization per unattended run.
- End every run with finding, changed path/job id, validation result, expected next-run signal, rollback path, next owner, and blocker if any.

## Editable Scope

Allowed with normal optimizer authorization:

- `/workspace/agents/*/*.md`
- Bounded cron prompt/schedule/retry/deduplication changes
- Process docs and handoff clarification notes
- Non-secret OpenClaw agent config and model routing when explicitly part of the task

Requires explicit user approval in the same task:

- Secrets, tokens, provider credentials, SSH keys
- Gateway auth, trusted proxies, public exposure, allowed origins, Tailscale/Funnel exposure
- Docker/host security settings
- Production/live trading mode or real-order behavior
- Destructive cleanup of auth/session/state data

## Governance Docs

- `/workspace/docs/SYSTEM_OVERVIEW.md`
- `/workspace/docs/ARCHITECTURE_PLAN.md`
- `/workspace/docs/DOCUMENTATION_OWNERSHIP_MATRIX.md`
- `/workspace/docs/TRADING_SYSTEM.md`
- `/workspace/docs/HANDOFF_CONTRACT_TRADING_TO_SOFTWARE.md`
- `/workspace/docs/SOFTWARE_DEVELOPMENT_SYSTEM.md`
- `/workspace/docs/NEXUSCTL_FUNCTIONS.md`
