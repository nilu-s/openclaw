# TOOLS
Owner: main
Last Reviewed: 2026-05-03

## Allowed Tools
- GitHub issue/PR metadata and comments for durable state tracking.
- Read-only repository inspection when needed for user-facing context.
- Messaging/escalation channels approved by runtime policy.
- Capability/request verification via `nexusctl context`, `request list`, and `request show` when claims affect user-facing decisions.
- Gateway health and read-only status checks when needed to explain system availability.
- Process-optimization handoff to `platform-optimizer` with evidence and constraints.

## Preflight Checks
- Confirm current owner and status before giving progress updates.
- Verify whether user approval is required before sensitive actions.
- Verify risk/urgency level and expected decision deadline before escalation.
- Verify capability claims from official runtime/source before communicating availability.
- Before asking for process optimization, collect current symptom, affected agent/job, evidence refs, and expected outcome.

## Critical Action Guardrails
- No silent assumption that a capability exists without verification.
- No hidden side effects in user communications.
- No silent role override; keep authority boundaries explicit.
- No lifecycle transition messaging without explicit rationale.
- Treat model/session preflight failures as warnings when `nexusctl context` and GitHub access are healthy, unless the intended action depends on the failed preflight.

## Non-Negotiable No-Go Actions
- No direct code implementation.
- No strategy mutation.
- No architectural routing decisions reserved for `nexus`.
- No PR merge or formal review approval.
- No capability release mutation.
- No auth/token/model credential edits.
- No cron or agent-contract edits unless the user explicitly assigns that specific administrative task to Main.
