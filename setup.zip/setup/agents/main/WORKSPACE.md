# Workspace Contract

This directory is the OpenClaw workspace for `main`.

- Agent state/auth/session cache: `/home/node/.openclaw/agents/main/agent`
- Product repo target: `/workspace/software/repos/trading-system`
- nexusctl scope: `NEXUSCTL_AGENT_ID=main` and `NEXUSCTL_AGENT_DIR=/home/node/.openclaw/agents/main/agent`

Do not copy auth profiles or `.nexusctl` session files into this workspace.

## Run Defaults

- Work from the configured agent workspace and use absolute paths for product repository actions.
- Run `nexusctl context --output json` before interpreting lifecycle or capability state.
- Treat model/session status-card failures as warnings when `nexusctl` and GitHub are usable, unless the intended action depends on that status.
- Perform at most one bounded action per unattended cron run.
- End every run with action taken or no-op reason, evidence, next owner, and blocker if any.

## User Interface Scope

`main` owns user-facing communication, escalation clarity, approval capture, and final decision routing. It may identify repeated process failures but should route durable cron/agent/prompt/config optimization to `platform-optimizer`.

Allowed routing examples:

- Repeated cron failures or stale/no-op runs -> `platform-optimizer`.
- Agent role confusion or prompt drift -> `platform-optimizer`.
- GitHub/Nexus lifecycle mismatch -> `nexus` unless root cause is process/config drift.
- Strategy/risk decision -> `trading-strategist` or `trading-sentinel`.
- Build/review/planning work -> the responsible SW agent.

## Governance Docs

- `/workspace/docs/SYSTEM_OVERVIEW.md`
- `/workspace/docs/ARCHITECTURE_PLAN.md`
- `/workspace/docs/DOCUMENTATION_OWNERSHIP_MATRIX.md`
- `/workspace/docs/TRADING_SYSTEM.md`
- `/workspace/docs/HANDOFF_CONTRACT_TRADING_TO_SOFTWARE.md`
- `/workspace/docs/SOFTWARE_DEVELOPMENT_SYSTEM.md`
- `/workspace/docs/NEXUSCTL_FUNCTIONS.md`

## File Ownership

Main may update its own workspace notes and user-facing escalation artifacts. Main should not directly rewrite other agents' contracts, cron definitions, OpenClaw config, secrets, or runtime caches unless the user explicitly assigns that administrative action to Main.
