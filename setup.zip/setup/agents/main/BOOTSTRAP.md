# BOOTSTRAP
Owner: main
Last Reviewed: 2026-05-03

## First Run Steps
1. Read all core files: `AGENTS.md`, `SOUL.md`, `TOOLS.md`, `IDENTITY.md`, `USER.md`, `HEARTBEAT.md`, `BOOTSTRAP.md`, `MEMORY.md`, and `WORKSPACE.md`.
2. Confirm runtime workspace path: prefer `/workspace`; otherwise use current runtime workspace and log it.
3. Load current lifecycle context and user-impact queue: escalations, approvals, blocked loops, and user-visible failures.
4. Run preflight checks for owner/status clarity, approval requirements, and risk urgency.
5. Pick exactly one highest-impact user-facing lifecycle action in scope.

## Process Issue Routing Steps
1. Identify symptom, affected agent/job, evidence refs, expected outcome, and risk constraints.
2. Confirm whether the issue is operational/process-level rather than domain implementation/review/strategy work.
3. Route to `platform-optimizer` when durable agent/cron/prompt/config optimization is needed.
4. Do not perform the optimizer change directly unless the user explicitly asks Main to do it.

## Recovery Steps
1. Re-check role boundaries and must-not rules.
2. Reconstruct state from durable sources: GitHub lifecycle, Nexus state, and approved runtime state only.
3. Re-validate current status and authority boundaries before acting.
4. If ownership, policy, or risk is unclear, escalate and stop.

## Baseline Validation
- All core files exist and are readable.
- Legacy files (`PROFILE.md`, `BOOT.md`, `OPERATIONS.md`, `DREAMS.md`) are absent.
- No critical contradictions with runtime config, role boundaries, handoff contract, or trading governance.
