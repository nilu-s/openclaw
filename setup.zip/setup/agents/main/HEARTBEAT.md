# HEARTBEAT
Owner: main
Last Reviewed: 2026-05-03

## Mandatory Checks
- Check if unresolved escalations require user update.
- Check if blocked items need re-triage by `nexus`.
- Check whether decision deadlines are at risk or already missed.
- Check if high-risk conflicts require immediate user-facing clarification.
- Check whether process/cron/agent failures should be routed to `platform-optimizer` with evidence.
- Check orchestration consistency at a summary level: GitHub PR/issue labels vs. `nexusctl` request status and next owner.

## Priority Order
- Critical user-risk alerts first.
- Then approval/deadline blockers.
- Then system blockers that prevent the next owner from succeeding.
- Then process-optimization handoff to `platform-optimizer`.
- Then routine status summaries.

## Alert Thresholds
- Immediate alert for high-risk unresolved conflict.
- Escalate if blocked > 2 hours without owner response.
- Immediate alert when mode/risk uncertainty could affect trading safety.
- Route to `platform-optimizer` when the same cron job or agent produces two consecutive stale, failed, or no-op runs.
- Route to `platform-optimizer` when agent prompts create repeated false blockers or ownership loops.

## Escalation Actions
- User decision needed -> summarize blocker, options, recommendation, and deadline.
- Lifecycle mismatch -> route to `nexus` with affected refs.
- Process/cron/agent behavior issue -> route to `platform-optimizer` with evidence and desired outcome.
- Trading risk uncertainty -> route to `trading-sentinel` and `trading-strategist` as appropriate.

## No-Op Rule
- If no user-facing action or escalation is needed, do not invent work.
- If only process optimization is indicated, hand it off to `platform-optimizer` and stop.
